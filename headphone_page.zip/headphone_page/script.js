/* ============================================================
   SONY WH-1000XM6 — Scroll-Linked Image Sequence Engine
   ============================================================ */

(function () {
  'use strict';

  // --- Configuration ---
  const SEQ1_DIR = 'ezgif-8959e964f20dc246-jpg';
  const SEQ2_DIR = 'ezgif-8bc0b8dee7b53d9b-jpg';
  const FRAME_COUNT = 240;
  const TOTAL_FRAMES = FRAME_COUNT * 2; // two sequences stitched

  // Storytelling beat ranges (as fraction of total scroll 0→1)
  const BEATS = [
    { id: 'overlay-hero',        start: 0.00, end: 0.10, peak: 0.04 },
    { id: 'overlay-engineering',  start: 0.10, end: 0.28, peak: 0.18 },
    { id: 'overlay-anc',         start: 0.28, end: 0.46, peak: 0.36 },
    { id: 'overlay-sound',       start: 0.46, end: 0.64, peak: 0.54 },
    { id: 'overlay-driver',      start: 0.64, end: 0.82, peak: 0.72 },
    { id: 'overlay-cta',         start: 0.84, end: 1.00, peak: 0.94 },
  ];

  // --- DOM refs ---
  const canvas          = document.getElementById('sequenceCanvas');
  const ctx             = canvas.getContext('2d');
  const scrollContainer = document.getElementById('scrollContainer');
  const canvasWrapper   = document.getElementById('canvasWrapper');
  const navbar          = document.getElementById('navbar');
  const loader          = document.getElementById('loader');
  const loaderProgress  = document.getElementById('loader-progress');
  const scrollProgress  = document.getElementById('scrollProgress');

  // Preload overlay elements
  const overlayEls = BEATS.map(b => document.getElementById(b.id));

  // --- State ---
  let seq1Images = [];
  let seq2Images = [];
  let currentFrame = -1;
  let imagesLoaded = 0;
  let isReady = false;
  let rafId = null;

  // --- Helpers ---
  function framePath(dir, index) {
    const num = String(index).padStart(3, '0');
    return `${dir}/ezgif-frame-${num}.jpg`;
  }

  function clamp(v, min, max) {
    return Math.max(min, Math.min(max, v));
  }

  function lerp(a, b, t) {
    return a + (b - a) * t;
  }

  // Ease-in-out for overlay visibility
  function fadeEnvelope(progress, start, end, peak) {
    if (progress < start || progress > end) return 0;
    const fadeInEnd = lerp(start, peak, 0.6);
    const fadeOutStart = lerp(peak, end, 0.4);
    if (progress < fadeInEnd) {
      const t = (progress - start) / (fadeInEnd - start);
      return clamp(t, 0, 1);
    }
    if (progress > fadeOutStart) {
      const t = 1 - (progress - fadeOutStart) / (end - fadeOutStart);
      return clamp(t, 0, 1);
    }
    return 1;
  }

  // --- Canvas sizing ---
  function resizeCanvas() {
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    canvas.width = canvasWrapper.clientWidth * dpr;
    canvas.height = canvasWrapper.clientHeight * dpr;
    canvas.style.width = canvasWrapper.clientWidth + 'px';
    canvas.style.height = canvasWrapper.clientHeight + 'px';
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    drawFrame(currentFrame >= 0 ? currentFrame : 0);
  }

  // --- Draw a single frame (cover-fit) ---
  function drawFrame(globalIdx) {
    let img;
    if (globalIdx < FRAME_COUNT) {
      img = seq1Images[globalIdx];
    } else {
      img = seq2Images[globalIdx - FRAME_COUNT];
    }
    if (!img || !img.complete || !img.naturalWidth) return;

    const cw = canvasWrapper.clientWidth;
    const ch = canvasWrapper.clientHeight;
    const iw = img.naturalWidth;
    const ih = img.naturalHeight;

    // Cover fit
    const canvasRatio = cw / ch;
    const imgRatio = iw / ih;
    let drawW, drawH, dx, dy;
    if (imgRatio > canvasRatio) {
      drawH = ch;
      drawW = ch * imgRatio;
    } else {
      drawW = cw;
      drawH = cw / imgRatio;
    }
    dx = (cw - drawW) / 2;
    dy = (ch - drawH) / 2;

    ctx.clearRect(0, 0, cw, ch);
    ctx.drawImage(img, dx, dy, drawW, drawH);
  }

  // --- Scroll handler ---
  function onScroll() {
    if (rafId) return;
    rafId = requestAnimationFrame(updateFrame);
  }

  function updateFrame() {
    rafId = null;
    if (!isReady) return;

    const rect = scrollContainer.getBoundingClientRect();
    const totalScroll = scrollContainer.scrollHeight - window.innerHeight;
    const scrollTop = -rect.top;
    const progress = clamp(scrollTop / totalScroll, 0, 1);

    // --- Determine frame index ---
    const globalIdx = clamp(Math.round(progress * (TOTAL_FRAMES - 1)), 0, TOTAL_FRAMES - 1);

    if (globalIdx !== currentFrame) {
      currentFrame = globalIdx;
      drawFrame(currentFrame);
    }

    // --- Navbar scroll effect ---
    if (scrollTop > 50) {
      navbar.classList.add('scrolled');
    } else {
      navbar.classList.remove('scrolled');
    }

    // --- Scroll progress bar ---
    scrollProgress.style.width = (progress * 100) + '%';
    if (progress > 0.01 && progress < 0.99) {
      scrollProgress.classList.add('active');
    } else {
      scrollProgress.classList.remove('active');
    }

    // --- Text overlays ---
    BEATS.forEach((beat, i) => {
      const el = overlayEls[i];
      if (!el) return;
      const alpha = fadeEnvelope(progress, beat.start, beat.end, beat.peak);
      if (alpha <= 0.01) {
        el.classList.remove('visible');
        el.style.opacity = 0;
        el.style.transform = 'translateY(24px)';
      } else {
        el.classList.add('visible');
        el.style.opacity = alpha;
        el.style.transform = `translateY(${(1 - alpha) * 24}px)`;
      }
    });
  }

  // --- Image loader ---
  function preloadImages() {
    let loaded = 0;
    const total = FRAME_COUNT * 2;

    function onLoad() {
      loaded++;
      const pct = Math.round((loaded / total) * 100);
      loaderProgress.textContent = pct + '%';

      // Show first frame as soon as sequence 1 frame 1 is loaded
      if (loaded === 1 && seq1Images[0] && seq1Images[0].complete) {
        resizeCanvas();
        drawFrame(0);
        currentFrame = 0;
      }

      if (loaded >= total) {
        isReady = true;
        loader.classList.add('hidden');
        updateFrame();
      }
    }

    // Load sequence 1
    for (let i = 1; i <= FRAME_COUNT; i++) {
      const img = new Image();
      img.src = framePath(SEQ1_DIR, i);
      img.onload = onLoad;
      img.onerror = onLoad; // count errors too to not stall
      seq1Images[i - 1] = img;
    }

    // Load sequence 2
    for (let i = 1; i <= FRAME_COUNT; i++) {
      const img = new Image();
      img.src = framePath(SEQ2_DIR, i);
      img.onload = onLoad;
      img.onerror = onLoad;
      seq2Images[i - 1] = img;
    }
  }

  // --- Init ---
  function init() {
    resizeCanvas();
    window.addEventListener('scroll', onScroll, { passive: true });
    window.addEventListener('resize', resizeCanvas);
    preloadImages();

    // Smooth scroll for nav links
    document.querySelectorAll('a[href^="#"]').forEach(link => {
      link.addEventListener('click', (e) => {
        const target = document.querySelector(link.getAttribute('href'));
        if (target) {
          e.preventDefault();
          target.scrollIntoView({ behavior: 'smooth' });
        }
      });
    });
  }

  // Wait for DOM
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

})();
